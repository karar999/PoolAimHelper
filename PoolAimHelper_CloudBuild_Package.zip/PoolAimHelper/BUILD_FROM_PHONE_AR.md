# بناء APK من الهاتف عبر GitHub Actions

1. أنشئ حساباً في GitHub من المتصفح وافتح مستودعاً جديداً (Repository) باسم PoolAimHelper، واجعله Public أو Private.
2. فك ضغط ملف المشروع على الهاتف.
3. ارفع محتويات مجلد PoolAimHelper إلى المستودع مع الحفاظ على المجلدات كما هي، بما فيها `.github/workflows/android-apk.yml`.
4. افتح تبويب Actions في المستودع، ثم اختر Build Android APK.
5. اضغط Run workflow وانتظر انتهاء البناء بنجاح.
6. افتح نتيجة التشغيل الناجحة، ثم نزّل Artifact باسم PoolAimHelper-debug-apk.
7. فك ضغط الـ Artifact؛ ستجد ملف APK بداخله.

ملاحظة: هذا المسار يبني نسخة Debug للتجربة. لم يتم اختبار البناء بعد في هذه الحزمة؛ نجاحه يتوقف على سلامة المشروع والاعتمادات المتاحة وقت البناء.
