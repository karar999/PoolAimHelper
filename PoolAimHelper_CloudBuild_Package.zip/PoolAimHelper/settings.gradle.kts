rootProject.name = "PoolAimHelper"
include(":app")
