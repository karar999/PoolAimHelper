package com.example.poolaimhelper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/** A screen-size-independent, draggable billiards line-training overlay. */
class AimOverlayView(context: Context) : View(context) {

    private val tableRect = RectF()
    private val cuePos = PointF()
    private val aimPos = PointF()
    private var activeHandle = 0
    var isLocked = false
        set(value) {
            field = value
            invalidate()
        }

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = dp(2f)
        style = Paint.Style.STROKE
    }
    private val bankPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.YELLOW
        strokeWidth = dp(1.7f)
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(dp(7f), dp(5f)), 0f)
    }
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(170, 56, 189, 248)
        strokeWidth = dp(1.5f)
        style = Paint.Style.STROKE
    }
    private val handlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(220, 2, 132, 199)
        style = Paint.Style.FILL
    }

    private fun dp(value: Float): Float = value * resources.displayMetrics.density

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w <= 0 || h <= 0) return
        val marginX = w * 0.08f
        val marginY = h * 0.18f
        tableRect.set(marginX, marginY, w - marginX, h - marginY)
        cuePos.set(tableRect.left + tableRect.width() * 0.28f, tableRect.centerY())
        aimPos.set(tableRect.left + tableRect.width() * 0.72f, tableRect.top + tableRect.height() * 0.32f)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (isLocked || tableRect.isEmpty) return

        canvas.drawRoundRect(tableRect, dp(8f), dp(8f), borderPaint)

        var ox = cuePos.x
        var oy = cuePos.y
        val angle = atan2(aimPos.y - cuePos.y, aimPos.x - cuePos.x)
        var dx = cos(angle)
        var dy = sin(angle)

        for (bounce in 0..2) {
            val hit = intersectBox(ox, oy, dx, dy) ?: break
            canvas.drawLine(ox, oy, hit.x, hit.y, if (bounce == 0) linePaint else bankPaint)
            if (hit.nx != 0f) dx = -dx
            if (hit.ny != 0f) dy = -dy
            ox = hit.x + dx * dp(1f)
            oy = hit.y + dy * dp(1f)
        }

        canvas.drawCircle(cuePos.x, cuePos.y, dp(10f), handlePaint)
        canvas.drawCircle(aimPos.x, aimPos.y, dp(10f), handlePaint)
    }

    private data class HitResult(val x: Float, val y: Float, val nx: Float, val ny: Float)

    private fun intersectBox(ox: Float, oy: Float, dx: Float, dy: Float): HitResult? {
        var tMin = Float.POSITIVE_INFINITY
        var nx = 0f
        var ny = 0f

        if (dx > 0.0001f) {
            val t = (tableRect.right - ox) / dx
            if (t > 0f && t < tMin) { tMin = t; nx = -1f; ny = 0f }
        } else if (dx < -0.0001f) {
            val t = (tableRect.left - ox) / dx
            if (t > 0f && t < tMin) { tMin = t; nx = 1f; ny = 0f }
        }
        if (dy > 0.0001f) {
            val t = (tableRect.bottom - oy) / dy
            if (t > 0f && t < tMin) { tMin = t; nx = 0f; ny = -1f }
        } else if (dy < -0.0001f) {
            val t = (tableRect.top - oy) / dy
            if (t > 0f && t < tMin) { tMin = t; nx = 0f; ny = 1f }
        }
        if (!tMin.isFinite()) return null
        return HitResult(ox + dx * tMin, oy + dy * tMin, nx, ny)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (isLocked) return false
        val x = event.x
        val y = event.y
        val handleRadius = dp(28f)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                activeHandle = when {
                    hypot(x - cuePos.x, y - cuePos.y) < handleRadius -> 1
                    hypot(x - aimPos.x, y - aimPos.y) < handleRadius -> 2
                    else -> 0
                }
                return activeHandle != 0
            }
            MotionEvent.ACTION_MOVE -> {
                when (activeHandle) {
                    1 -> cuePos.set(x.coerceIn(tableRect.left, tableRect.right), y.coerceIn(tableRect.top, tableRect.bottom))
                    2 -> aimPos.set(x.coerceIn(tableRect.left, tableRect.right), y.coerceIn(tableRect.top, tableRect.bottom))
                    else -> return false
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val handled = activeHandle != 0
                activeHandle = 0
                return handled
            }
        }
        return false
    }
}
